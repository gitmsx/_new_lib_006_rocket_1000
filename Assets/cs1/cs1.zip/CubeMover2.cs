﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// using Mathf;

public class CubeMover2 : MonoBehaviour
{

    public float moveTime = 1.5f;

    Vector3 startPosition;
    Vector3 targetPosition;
    float targetTime;

    void Move(Vector3 move)
    {

        targetTime = Time.time + moveTime;
        startPosition = transform.position;

        targetPosition = transform.position + move;





    }


    void FixedUpdate()
    {

        Sstabil();
    }

    void Sstabil()
    {

        Vector3 pos55 = transform.position;
        transform.position = new Vector3(Mathf.Round(pos55.x), Mathf.Round(pos55.y), Mathf.Round(pos55.z));

    }
    void Update()
    {

        if (targetTime > Time.time)
        {



            transform.position = Vector3.Lerp(startPosition, targetPosition, 1 - (targetTime - Time.time) / moveTime);

        }
        else
        {

            if (Input.GetKey(KeyCode.UpArrow))
            {
                Move(Vector3.forward);
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                Move(Vector3.back);
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                Move(Vector3.left);
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                Move(Vector3.right);
            }

        }

    }
}

