﻿

using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class move5 : MonoBehaviour
{
    // Start is called before the first frame update

    public Rigidbody rb;
    [SerializeField] private float speed_x = 110.0f;
    [SerializeField] private float speed_y = 14.0f;
    [SerializeField] private float speed_z = 102.0f;
    [SerializeField] private Vector3 lt = new Vector3(0, 5, 0); //kind of in the middle of the screen, rather than at the top (play)
    public float rotationSpeed = 100.0f;


    void Start()
    {

    }
    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        //        rb.angularDrag = 2;
    }
    // Update is called once per frame
    void Update()
    {
 
        float force_z = Input.GetAxis("Vertical") * speed_z;
        float rotation_y = Input.GetAxis("Horizontal") * speed_y;
        float rotation_z = 0;

        // Make it move 10 meters per second instead of 10 meters per frame...
        force_z *= Time.deltaTime;
        rotation_y *= Time.deltaTime;



        rb.AddRelativeForce(0, 0, force_z);
        rb.AddRelativeTorque(0, rotation_y, 0, ForceMode.Impulse);
        // Move translation along the object's z-axis
        //  transform.Translate(0, 0, translation);


    }
}
