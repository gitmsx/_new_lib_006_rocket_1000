﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class bul3 : MonoBehaviour
{

    public float StartTime = 0;
    public float DestroyTime = 5;
    private GameObject bulletClone;

    public float bulletSpeed = 100;
    public Rigidbody bullet;
    public GameObject BulletPF;



    void Fire()
    {

        bulletClone = Instantiate(BulletPF, transform.position, transform.rotation);
        bulletClone.GetComponent<Rigidbody>().velocity = transform.forward * bulletSpeed;

        Destroy(bulletClone, DestroyTime);

    }

    void Update()
    {
        //  StartTime += Time.deltaTime;



        if (Input.GetButtonDown("Fire1"))
            Fire();
    }
}